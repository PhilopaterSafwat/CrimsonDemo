import React from 'react'
import style from './PopupVideo.module.css'
import Popup from 'reactjs-popup';
import 'reactjs-popup/dist/index.css';

export default function PopupVideo() {


    return <>
        <h1 className='text-5xl'>PopupVideo</h1>
    </>
}

