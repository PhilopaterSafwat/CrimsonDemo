import React from 'react'
import style from './Reservation.module.css'

export default function Reservation() {

    
    return <>
        <h1 className='text-5xl'>Reservation</h1>

    </>
}

