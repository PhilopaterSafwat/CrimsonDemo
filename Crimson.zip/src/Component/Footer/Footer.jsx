import React from 'react'
import style from './Footer.module.css'

export default function Footer() {

    
    return <>
        <h1 className='text-5xl'>Footer</h1>

    </>
}

