import React from 'react'
import style from './Menu.module.css'

export default function Menu() {

    
    return <>
        <h1 className='text-5xl'>Menu</h1>

    </>
}

